# Job Application Tracker (Django)

A single-page CRUD app for tracking job applications: one form to add/edit, one list below, no separate pages. Built with Django (server-rendered, no separate frontend framework).

## Stack
- Django (views, models, forms, templates, ORM)
- SQLite (Django's default database)

## Project layout
```
job-tracker-django/
├── manage.py
├── requirements.txt
├── config/              (project settings, urls)
│   ├── settings.py
│   └── urls.py
└── tracker/             (the app)
    ├── models.py        (Application model)
    ├── forms.py         (ApplicationForm)
    ├── views.py          (index view handles list + create + edit; delete_application handles delete)
    ├── urls.py
    ├── admin.py
    └── templates/tracker/index.html   (the single-page form + list UI)
```

## Setup

```bash
python -m venv venv
# Windows: venv\Scripts\activate
# macOS/Linux: source venv/bin/activate

pip install -r requirements.txt

python manage.py migrate
python manage.py runserver
```

Open http://127.0.0.1:8000 — the form and list are both on that one page.

## How it works
- Fill the form and click "Add Application" to create an entry (handled by `index` view via POST)
- Click "Edit" on any list item — the page reloads with `?edit=<id>` in the URL and the form is pre-filled; submitting saves changes to that record
- Click "Delete" — a small inline form POSTs to `delete_application`, which removes the record and redirects back
- Status badges (Applied / Interview / Offer / Rejected) are color-coded

## Optional: Django admin
Create a superuser to browse/edit records through Django's built-in admin UI:
```bash
python manage.py createsuperuser
```
Then visit http://127.0.0.1:8000/admin
