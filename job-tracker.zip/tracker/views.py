from datetime import date

from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.http import require_POST

from .models import Application
from .forms import ApplicationForm


def index(request):
    """Single-window view: form + list on one page. Handles create and update."""
    edit_id = request.GET.get("edit")
    editing = None

    if request.method == "POST":
        instance = None
        post_edit_id = request.POST.get("edit_id")
        if post_edit_id:
            instance = get_object_or_404(Application, pk=post_edit_id)
        form = ApplicationForm(request.POST, instance=instance)
        if form.is_valid():
            form.save()
            return redirect("index")
    else:
        if edit_id:
            editing = get_object_or_404(Application, pk=edit_id)
            form = ApplicationForm(instance=editing)
        else:
            form = ApplicationForm(initial={"date_applied": date.today()})

    applications = Application.objects.all()

    return render(
        request,
        "tracker/index.html",
        {"form": form, "applications": applications, "editing": editing},
    )


@require_POST
def delete_application(request, pk):
    application = get_object_or_404(Application, pk=pk)
    application.delete()
    return redirect("index")
